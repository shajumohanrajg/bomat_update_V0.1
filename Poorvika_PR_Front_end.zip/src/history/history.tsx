import { createBrowserHistory } from "history";
//helps to store->sagas page
//navigate one place to another place
export default createBrowserHistory();
